import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;
const host = process.env.HOST || '0.0.0.0';

app.use(express.json());

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'quickfixpro-production',
      },
    },
  });
}

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'QuickFixPro Bangalore API' });
});

app.post('/api/gemini/chat', async (req, res) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: 'AI Assistant is not configured on this server.',
      });
    }

    const { message, history } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message text is required.' });
    }

    const systemInstruction = `You are the Quick Fix Pro AI Assistant, Bangalore's expert doorstep appliance repair diagnostic engine.
Your role:
1. Help customers diagnose problems with home appliances (Washing Machines, Refrigerators, Air Conditioners, Microwave Ovens, Water Purifiers, Televisions).
2. Provide transparent Bangalore doorstep repair cost estimates (in ₹ INR).
3. Highlight Quick Fix Pro guarantees: ₹199 Inspection Fee (WAIVED on repair), 6-Month Written Warranty Card, 90-Minute Express Doorstep Dispatch across Bangalore, Hotline: +91 80959 96638.`;

    const chat = ai.chats.create({
      model: 'gemini-3.8-flash',
      config: { systemInstruction },
    });

    if (Array.isArray(history)) {
      for (const msg of history) {
        if (msg.role === 'user' && msg.content) {
          await chat.sendMessage({ message: msg.content });
        }
      }
    }

    const response = await chat.sendMessage({ message });
    const replyText = response.text || 'I am here to assist with your appliance repair needs in Bangalore.';

    res.json({ success: true, reply: replyText });
  } catch (error) {
    console.error('Gemini Chat Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process AI Assistant message.',
      details: error?.message || 'Unknown error',
    });
  }
});

const distDir = path.resolve(__dirname, 'dist');
app.use(express.static(distDir, { maxAge: '7d' }));
app.get('*', (_req, res) => {
  res.sendFile(path.join(distDir, 'index.html'));
});

app.listen(port, host, () => {
  console.log(`Quick Fix Pro production server running at http://${host}:${port}`);
});
